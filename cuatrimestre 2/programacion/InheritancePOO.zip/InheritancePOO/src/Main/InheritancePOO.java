package Main;

import SubClasses.*;

public class InheritancePOO {

    public static void main(String[] args) {
        //Calling Overriden Class Constructor
        Rectangle myRectangle = new Rectangle(4, 7); 
        double perimeter = myRectangle.getPerimeter();
        System.out.println("Perímetro del Rectángulo: " + perimeter);
        double area = myRectangle.getArea();
        System.out.println("Área del Rectángulo: " + area);
        
        Square mySquare = new Square();
        //Create a 'set' method to assign value to private/protected attribute
        mySquare.setSide(4); 
        perimeter = mySquare.getPerimeter();
        System.out.println("Perímetro del cuadrado: " + perimeter);
        area = mySquare.getArea();
        System.out.println("Área del cuadrado: " + area);
        
        Circle myCircle = new Circle();
        myCircle.diameter = 3;
        perimeter = myCircle.getPerimeter();
        System.out.println("Perímetro del círculo: " + perimeter);
        area = myCircle.getArea();
        System.out.println("Área del círculo: " + area);
    }
    
}
