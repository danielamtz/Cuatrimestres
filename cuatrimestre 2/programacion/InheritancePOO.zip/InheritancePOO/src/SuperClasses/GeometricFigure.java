package SuperClasses;

public abstract class GeometricFigure {
    protected double value1;
    
    protected abstract double getPerimeter();
    protected abstract double getArea();
}
