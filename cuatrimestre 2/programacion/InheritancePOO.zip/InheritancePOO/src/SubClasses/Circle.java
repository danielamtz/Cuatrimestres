package SubClasses;

import SuperClasses.GeometricFigure;

public class Circle extends GeometricFigure {
    public double diameter;
    
    @Override
    public double getPerimeter(){
        return Math.PI * diameter;
    }
    
    @Override
    public double getArea(){
        double radio = diameter/2;
        return Math.PI * Math.pow(radio, 2);
    }
}
