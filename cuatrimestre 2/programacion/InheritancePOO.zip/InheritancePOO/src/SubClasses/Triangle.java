package SubClasses;

import SuperClasses.GeometricFigure;

public class Triangle extends GeometricFigure {
    public double base, height;
    public double side1, side2, side3;
    
    @Override
    public double getPerimeter(){
        return side1 + side2 + side3;
    }
    
    @Override
    public double getArea(){
        return base * height / 2;
    }
}
