package SubClasses;

import SuperClasses.GeometricFigure;

public class Rectangle extends GeometricFigure{
    private double base, height;
    
    //Default Constructor ** new Rectangle() **
    public Rectangle(){}
    
    //Overriden Constructor ** new Rectangle(value1, value2) **
    public Rectangle(double _base, double _height){
        this.base = _base;
        this.height = _height;
    }
    
    @Override
    public double getPerimeter(){
        return 2 * base + 2 * height;
    }
    
    @Override
    public double getArea(){
        return base * height;
    }
}
