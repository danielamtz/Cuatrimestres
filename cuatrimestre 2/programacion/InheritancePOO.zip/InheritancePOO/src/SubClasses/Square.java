package SubClasses;

import SuperClasses.GeometricFigure;

public class Square extends GeometricFigure {
    
    @Override
    public double getPerimeter(){
        return value1 * 4;
    }
    
    @Override
    public double getArea(){
        return value1 * value1;
    }
    
    //Method created to assign value to private/protected attribute
    public void setSide(double value){
        value1 = value;
    }
}
